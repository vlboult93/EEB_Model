######################################################################################
#                                                                                    #
#       SCRIPT TO RUN LOCAL SENSITIVITY ANALYSIS ON EEB NETLOGO MODEL                #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 11th April 2018                                                        #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

## simulate() takes the following arguments:
## param.set = priors for all parameters
## parameter.names = names of all parameters (as per NetLogo model)
## no.repeated.sims = number of repeated simulations to account for stochasticity
## nl.obj = netlogo instance (NULL in parallel)
## trace.progress = progress keeper (doesn't work in parallel)
## iter.length = number of parameter sets
## function.name = name of function

#-------------------------------------------------------------------------------------
# Simulation function
#-------------------------------------------------------------------------------------
simulate <- function(param.set, parameter.names, no.repeated.sim, nl.obj, trace.progress, iter.length, function.name) {
  # some security checks
  if (length(param.set) != length(parameter.names))
  { print(param.set)
    print(parameter.names)
    stop("Wrong length of param.set!") }
  if (no.repeated.sim <= 0)
  { stop("Number of repetitions must be > 0!") }
  if (length(parameter.names) <= 0)
  { stop("Length of parameter.names must be > 0!") }
  
  # an empty list to save the simulation results
  eval.vals <- NULL
  
  # repeated simulations (to control stochasticity)
  for (i in 1:no.repeated.sim)
  {
    
    # run setup procedure
    NLCommand("setup", nl.obj = nl.obj)
    
    # set NetLogo parameters to current parameter values
    lapply(seq(1:length(parameter.names)), function(x) {NLCommand("set ", parameter.names[x], param.set[x], nl.obj = nl.obj)})

    # run full model
    NLDoCommand(6105, "go", nl.obj=nl.obj)
    # retrieve population data
    SA.res <- NLReport(c("count turtles", "a_death_tot", "birth_tot", "c_death_tot"), nl.obj = nl.obj)
    SA.res <- unlist(SA.res)
    # append to former results
    eval.vals <- rbind(eval.vals, SA.res)
  }
  
  # print the progress if requested
  if (trace.progress == TRUE)
  {
    already.processed <- get("already.processed",env=globalenv()) + 1
    assign("already.processed", already.processed, env=globalenv())
    print(paste("processed (",function.name,"): ", already.processed / iter.length * 100, "%", sep = ""))
  }
  
  return(eval.vals)
}

