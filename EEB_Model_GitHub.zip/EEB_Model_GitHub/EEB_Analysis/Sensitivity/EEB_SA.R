######################################################################################
#                                                                                    #
#       SCRIPT TO RUN LOCAL SENSITIVITY ANALYSIS ON EEB NETLOGO MODEL                #
#       Author: Vicky Boult                                                          #
#       Date: 11th April 2018                                                        #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

# load required packages
library(RNetLogo)        # hook up NL and R
library(parallel)        # run simulation sin parallel

#-------------------------------------------------------------------------------------
# I. Initialise R for use with NetLogo
#-------------------------------------------------------------------------------------
# set working directory to location where NetLogo .jar file is located
setwd("C:/Program Files/NetLogo 6.0.2/app")
# the NetLogo installation path
nl.path <- getwd()
# the path to the NetLogo model file
model.path  <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Model/EEB_240418.nlogo"
# the simulation function
simfun.path <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Sensitivity/SA_simulation.R"
# how many repetitions for each parameter set should be run (to control stochasticity)?
no.repeated.sim <- 10
# load the code of the simulation function
source(file = simfun.path)

#-------------------------------------------------------------------------------------
# II. Generate parameter sets for SA
#-------------------------------------------------------------------------------------
# read in best fitting prior parameter set
ref.values <- read.csv("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Sensitivity/best1priors.csv", header = T)
ref.values <- as.list(ref.values)
# reference values in a data frame
ref.val.df <- as.data.frame(ref.values)

# generate values 10% above and below reference value for each parameter
# only one parameter adjusted during each model run, others remain fixed at reference value
stor_scaling    <- c(ref.val.df$stor_scaling[1] * 0.9, ref.val.df$stor_scaling[1], ref.val.df$stor_scaling[1] * 1.1,
                     rep(ref.val.df$stor_scaling[1], 30))
hsc             <- c(rep(ref.val.df$hsc[1],3), 
                     ref.val.df$hsc[1] * 0.9, ref.val.df$hsc[1], ref.val.df$hsc[1] * 1.1,
                     rep(ref.val.df$hsc[1],27))
maxIR_scaling   <- c(rep(ref.val.df$maxIR_scaling[1],6), 
                     ref.val.df$maxIR_scaling[1] * 0.9, ref.val.df$maxIR_scaling[1], ref.val.df$maxIR_scaling[1] * 1.1,
                     rep(ref.val.df$maxIR_scaling[1],24))
AE_veg          <- c(rep(ref.val.df$AE_veg[1],9), 
                     ref.val.df$AE_veg[1] * 0.9, ref.val.df$AE_veg[1], ref.val.df$AE_veg[1] * 1.1,
                     rep(ref.val.df$AE_veg[1],21))
con_eff         <- c(rep(ref.val.df$con_eff[1],12), 
                     ref.val.df$con_eff[1] * 0.9, ref.val.df$con_eff[1], ref.val.df$con_eff[1] * 1.1,
                     rep(ref.val.df$con_eff[1],18))
B_0             <- c(rep(ref.val.df$B_0[1],15), 
                     ref.val.df$B_0[1] * 0.9, ref.val.df$B_0[1], ref.val.df$B_0[1] * 1.1,
                     rep(ref.val.df$B_0[1],15))
E0              <- c(rep(ref.val.df$E0[1],18), 
                     ref.val.df$E0[1] * 0.9, ref.val.df$E0[1], ref.val.df$E0[1] * 1.1,
                     rep(ref.val.df$E0[1],12))
Epl             <- c(rep(ref.val.df$Epl[1],21), 
                     ref.val.df$Epl[1] * 0.9, ref.val.df$Epl[1], ref.val.df$Epl[1] * 1.1,
                     rep(ref.val.df$Epl[1],9))
back_mort       <- c(rep(ref.val.df$back_mort[1],24), 
                     ref.val.df$back_mort[1] * 0.9, ref.val.df$back_mort[1], ref.val.df$back_mort[1] * 1.1,
                     rep(ref.val.df$back_mort[1],6))
MR              <- c(rep(ref.val.df$MR[1],27), 
                     ref.val.df$MR[1] * 0.9, ref.val.df$MR[1], ref.val.df$MR[1] * 1.1,
                     rep(ref.val.df$MR[1],3))
DD              <- c(rep(ref.val.df$dd[1],30), 
                     ref.val.df$dd[1] * 0.9, ref.val.df$dd[1], ref.val.df$dd[1] * 1.1)
# SA parameter values dataframe
SAvals <- cbind(stor_scaling,hsc,maxIR_scaling,AE_veg,con_eff,B_0,E0,Epl,back_mort,MR,DD)
# parameter names
parameter.names <- names(ref.values)

#-------------------------------------------------------------------------------------
# III. Run the simulation for all parameter sets in PARALLEL
#-------------------------------------------------------------------------------------
# define functions required to run EEB in parallel
# the initialisation function - loads NetLogo model into each core
prepro <- function(dummy, gui, nl.path, model.path) {
  library(RNetLogo)
  NLStart(nl.path, gui = gui,  nl.jarname = "netlogo-6.0.2.jar")
  NLLoadModel(model.path)
}
# the simulation function
simfun <- simulate
# the quit function - closes NetLogo in each core
postpro <- function(x) {
  NLQuit()
}
# create cluster (use all cores except 1 so you can still do other things whilst ABC runs!)
processors <- detectCores() - 1
cl <- makeCluster(processors)
# run headless - MUCH quicker!
gui = F
# load NetLogo in each core
invisible(parLapply(cl, 1:processors, prepro, gui = gui, nl.path = nl.path, model.path = model.path))
# run simulations - 330 runs takes ~5 minutes
SAresults <- parApply(cl, SAvals, 1, simfun, 
                        no.repeated.sim = no.repeated.sim, 
                        nl.obj = NULL, trace.progress = F,
                        parameter.names = parameter.names, 
                        iter.length = nrow(as.data.frame(SAvals)),
                        function.name = "SA")
# quit NetLogo in each core
invisible(parLapply(cl, 1:processors, postpro))
#close cluster
stopCluster(cl)
# write out raw results to CSV file
write.table(SAresults, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/SA_runs.csv", sep = ",", row.names = FALSE)

#-------------------------------------------------------------------------------------
# IV. Analysis of SA results
#-------------------------------------------------------------------------------------
# read in raw SA results generated above
SAresults <- read.csv("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/SA_runs.csv", header = T)

# calculate mean and standard deviation of each model output across 10 repeated simulations
# (final population size, total no. adult deaths, total no. of calf deaths and total no. of births)
# first 10 rows of results = final population size
res_all <- NULL
pop_fun <- function(x) {
  f <- SAresults[1:10, x]
  mean_f <- mean(as.numeric(f))
  sd_f <- sd(as.numeric(f))
  res_f <- cbind(mean_f, sd_f)
  res_all <- rbind(res_all, res_f)
}
pop_SA <- t(sapply(1:33, pop_fun))
# rows 11-20 of results = total no. adult deaths
res_all <- NULL
ade_fun <- function(x) {
  f <- SAresults[11:20, x]
  mean_f <- mean(as.numeric(f))
  sd_f <- sd(as.numeric(f))
  res_f <- cbind(mean_f, sd_f)
  res_all <- rbind(res_all, res_f)
}
ade_SA <- t(sapply(1:33, ade_fun))
# rows 21-30 of results = total no. births
res_all <- NULL
bir_fun <- function(x) {
  f <- SAresults[21:30, x]
  mean_f <- mean(as.numeric(f))
  sd_f <- sd(as.numeric(f))
  res_f <- cbind(mean_f, sd_f)
  res_all <- rbind(res_all, res_f)
}
bir_SA <- t(sapply(1:33, bir_fun))
# rows 31-40 of results = total no. calf deaths
res_all <- NULL
cde_fun <- function(x) {
  f <- SAresults[31:40, x]
  mean_f <- mean(as.numeric(f))
  sd_f <- sd(as.numeric(f))
  res_f <- cbind(mean_f, sd_f)
  res_all <- rbind(res_all, res_f)
}
cde_SA <- t(sapply(1:33, cde_fun))

# define row names
param <- c(rep("stor_scaling",3),rep("hsc",3),rep("maxIR_scaling",3),
           rep("AE_veg",3),rep("con_eff",3),rep("B_0",3),rep("E0",3),rep("Epl",3),
           rep("back_mort",3),rep("MR",3),rep("DD",3))
# define proportional change in parameter values
val <- rep(c(0.9,1,1.1),11)
# combine names, proportional change and model outputs into dataframe
all_SA <- cbind.data.frame(param, val, pop_SA, ade_SA, bir_SA, cde_SA)
# define column headings
colnames(all_SA) <- c("param","val","pop_mean","pop_sd","ade_mean","ade_sd",
                      "bir_mean","bir_vsds","cde_mean","cde_sd")

# rows of df containing reference value parameter sets
ref_rows <- seq(from = 2, to = 33, by = 3)
# rows of df containing -10% change in parameter values
neg_rows <- seq(from = 1, to = 33, by = 3)
# rows of df containing +10% change in parameter values
pos_rows <- seq(from = 3, to = 33, by = 3)

# calculate sensitivity of each model output to changes in each parameter
pop_sens_mean <- (((all_SA[pos_rows[1:11],3] - all_SA[neg_rows[1:11],3]) / all_SA[ref_rows[1:11],3]) * 100) / 20
ade_sens_mean <- (((all_SA[pos_rows[1:11],5] - all_SA[neg_rows[1:11],5]) / all_SA[ref_rows[1:11],5]) * 100) / 20
bir_sens_mean <- (((all_SA[pos_rows[1:11],7] - all_SA[neg_rows[1:11],7]) / all_SA[ref_rows[1:11],7]) * 100) / 20
cde_sens_mean <- (((all_SA[pos_rows[1:11],9] - all_SA[neg_rows[1:11],9]) / all_SA[ref_rows[1:11],9]) * 100) / 20

# calculate standard error of sensitivity of each model output to changes in each parameter
pop_se <- sqrt((all_SA[pos_rows[1:11],4] / sqrt(10))^2 + (all_SA[neg_rows[1:11],4] / sqrt(10))^2)
ade_se <- sqrt((all_SA[pos_rows[1:11],6] / sqrt(10))^2 + (all_SA[neg_rows[1:11],6] / sqrt(10))^2)
bir_se <- sqrt((all_SA[pos_rows[1:11],8] / sqrt(10))^2 + (all_SA[neg_rows[1:11],8] / sqrt(10))^2)
cde_se <- sqrt((all_SA[pos_rows[1:11],10] / sqrt(10))^2 + (all_SA[neg_rows[1:11],10] / sqrt(10))^2)

# list of parameter names
param_names <- unique(param)
# create df of sensitivities and SE
sensitivities  <- cbind.data.frame(param_names, pop_sens_mean, pop_se, 
                                   ade_sens_mean, ade_se,
                                   bir_sens_mean, bir_se, 
                                   cde_sens_mean, cde_se)
# round values in df to 2 decimal places                                   
pop_means <- round(sensitivities$pop_sens_mean, 2)
ade_means <- round(sensitivities$ade_sens_mean, 2)
bir_means <- round(sensitivities$bir_sens_mean, 2)
cde_means <- round(sensitivities$cde_sens_mean, 2)
pop_ses <- round(sensitivities$pop_se, 2)
ade_ses <- round(sensitivities$ade_se, 2)
bir_ses <- round(sensitivities$bir_se, 2)
cde_ses <- round(sensitivities$cde_se, 2)
# insert +- sign between means and SE
pop_sens <- paste(pop_means, " \u00b1 ", pop_ses)
ade_sens <- paste(ade_means, " \u00b1 ", ade_ses)
bir_sens <- paste(bir_means, " \u00b1 ", bir_ses)
cde_sens <- paste(cde_means, " \u00b1 ", cde_ses)
# create final table
tabSA <- cbind.data.frame(param_names, pop_sens, bir_sens, ade_sens, cde_sens)
# column headings
colnames(tabSA) <- c("Parameter","Pop. size","Births","Adult Mort.","Calf Mort.")
# write to CSV file
write.csv(tabSA, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/SA_table.csv", row.names = F)

######################################################################################
