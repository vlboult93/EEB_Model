######################################################################################
#                                                                                    #
#       SIMULATION FUNCTION FOR EEB MODEL SCENARIOS                                  #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 8th May 2018                                                           #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

## simulate() takes the following arguments:
## param.set = priors for all parameters
## parameter.names = names of all parameters (as per NetLogo model)
## no.repeated.sims = number of repeated simulations to account for stochasticity
## nl.obj = netlogo instance (NULL in parallel)
## trace.progress = progress keeper (doesn't work in parallel)
## iter.length = number of parameter sets
## function.name = name of function
## area = total area represented by model 

#-------------------------------------------------------------------------------------
# Simulation function
#-------------------------------------------------------------------------------------
simulate <- function(param.set, parameter.names, no.repeated.sim, nl.obj, trace.progress, iter.length, function.name, area) {
  # some security checks
  if (length(param.set) != length(parameter.names))
  { print(param.set)
    print(parameter.names)
    stop("Wrong length of param.set!") }
  if (no.repeated.sim <= 0)
  { stop("Number of repetitions must be > 0!") }
  if (length(parameter.names) <= 0)
  { stop("Length of parameter.names must be > 0!") }
  
  # an empty list to save the simulation results
  eval.vals <- NULL
  
  # repeated simulations (to control stochasticity)
  for (i in 1:no.repeated.sim)
  {
    # create a random-seed for NetLogo from R, based on min/max of NetLogo's random seed
    NLCommand("random-seed",56492, nl.obj = nl.obj)
    
    # run setup procedure
    NLCommand("setup", nl.obj = nl.obj)
    
    # set NetLogo parameters to current parameter values
    lapply(seq(1:length(parameter.names)), function(x) {NLCommand("set ", parameter.names[x], param.set[x], nl.obj = nl.obj)})
    
    # set area represented by model
    NLCommand("set area", area, nl.obj = nl.obj)
    
    # advance model to 1st October 2000
    NLDoCommand(213,"go", nl.obj = nl.obj) 
    # record population size
    counts2000 <- as.data.frame(NLReport(c("count turtles"), nl.obj = nl.obj))
    colnames(counts2000) <- c("E1_1")
    # advance model by year and record population size annualy
    countRest <- function(x) {
      f <- NLDoReport(1, "repeat 365 [go]", c("count turtles"), as.data.frame = T, 
                      df.col.names = c(paste("E1_",x, sep = "")), nl.obj = nl.obj)
      return(f)
    }
    countsAll <- lapply(2:17, countRest)
    # combine all results 2000-2016
    countsAll <- unlist(countsAll)
    countsAll <- t(as.data.frame(countsAll))
    counts.df <- merge.data.frame(counts2000, countsAll, all = T)
    
    # append results to previous results
    eval.vals <- rbind(eval.vals, counts.df)
  }
  
  # print the progress if requested
  if (trace.progress == TRUE)
  {
    already.processed <- get("already.processed",env=globalenv()) + 1
    assign("already.processed", already.processed, env=globalenv())
    print(paste("processed (",function.name,"): ", already.processed / iter.length * 100, "%", sep = ""))
  }
  
  # return the mean of the repeated simulation results
  #if (no.repeated.sim > 1)
  #{
  #  return(eval.vals)
  #  #return(colMeans(eval.vals))
  #}
  #else {
  return(eval.vals)
  #}
}