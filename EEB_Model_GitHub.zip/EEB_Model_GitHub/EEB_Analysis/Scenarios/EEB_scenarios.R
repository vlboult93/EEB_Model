######################################################################################
#                                                                                    #
#       SCRIPT TO RUN HYPOTHETICAL RANGE REDUCTION SCENARIOS                         #
#       Author: Vicky Boult                                                          #
#       Date: 8th May 2018                                                           #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

# load required packages
library(RNetLogo)        # hook up NL and R
library(parallel)        # run simulation sin parallel
library(plyr)            # for manipulating outputs

#-------------------------------------------------------------------------------------
# I. Initialise R for use with NetLogo
#-------------------------------------------------------------------------------------
# set working directory to location where NetLogo .jar file is located
setwd("C:/Program Files/NetLogo 6.0.2/app")
# the NetLogo installation path
nl.path <- getwd()
# the path to the NetLogo model file
model.path  <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Model/EEB_240418.nlogo"
# the simulation function
simfun.path <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Scenarios/EEB_simulation_scenarios.R"
# load the code of the simulation function
source(file = simfun.path)
# read in accepted parameter sets 
param.val <- read.csv("[INSERT FILE PATH]/best30priors.csv", header = T)

#-------------------------------------------------------------------------------------
# II. Run the simulation for all parameter sets in PARALLEL
#-------------------------------------------------------------------------------------
# define functions required to run EEB in parallel
# the initialisation function - loads NetLogo model into each core
prepro <- function(dummy, gui, nl.path, model.path) {
  library(RNetLogo)
  NLStart(nl.path, gui = gui,  nl.jarname = "netlogo-6.0.2.jar")
  NLLoadModel(model.path)
}
# the simulation function
simfun <- simulate
# the quit function
postpro <- function(x) {
  NLQuit()
}
# create cluster (use all cores except 1 so you can still do other things whilst ABC runs!)
processors <- detectCores() - 1
cl <- makeCluster(processors)
# run NetLogo in headless mode - MUCH quicker!
gui = F
# load NetLogo in each core
invisible(parLapply(cl, 1:processors, prepro, gui = gui, nl.path = nl.path, model.path = model.path))

# run simulations for 10% reduction in range (area = 0.9 * p)
results_area_90 <- parApply(cl, param.val, 1, simulate, 
                            no.repeated.sim = 1,
                            nl.obj = NULL, trace.progress = F,
                            parameter.names = names(param.val),
                            iter.length = 30,
                            function.name = "EX", area = 573427947)
# reorganize the results
results_area_90 <- ldply(results_area_90, data.frame)
# export  results 
write.table(results_area_90, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/scenario90_results.txt", row.names = F, sep = " ")

# run simulations for 50% reduction in range (are = 0.5 * p)
results_area_50 <- parApply(cl, param.val, 1, simulate, 
                            no.repeated.sim = 1,
                            nl.obj = NULL, trace.progress = F,
                            parameter.names = names(param.val),
                            iter.length = 30,
                            function.name = "EX", area = 31857108)
# reorganize the results
results_area_50 <- ldply(results_area_50, data.frame)
# export results 
write.table(results_area_50, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/scenario50_results.txt", row.names = F, sep = " ")

# quit NetLogo in each core
invisible(parLapply(cl, 1:processors, postpro))
# close cluster
stopCluster(cl)

#-------------------------------------------------------------------------------------
# III. Plot results
#-------------------------------------------------------------------------------------
# read in data again 
all.data <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Scenarios/EEB_ILVW_data.txt", header = T)
# only want to look at population size data
all.data <- all.data[,1:17]
# read in all prior parameter set dataframes
full.priors <- param.val
# read in all results dataframes
results90 <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/scenario90_results.txt", header = T, stringsAsFactors = F)
results50 <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/scenario50_results.txt", header = T, stringsAsFactors = F)

# set up 
par(mai = c(0.7,1,0.5,0.1), lwd = 2, mfrow = c(1,2))

# draw an empty plot
plot(x <- c(1:17)*10, all.data, xlim = c(-1, 183), ylim = c(0, 300), axes = FALSE, ann = FALSE, type = "n")
# add a border, axis titles and axes ticks to the plot
box(lwd = 1.5)
title(ylab = "Population size", line = 2.75, cex.lab = 1.5)
title(main = "10% Range Reduction", cex.lab = 1.5)
axis(1, at = seq(2, 180, by = 10), cex.axis = 1.5, cex.lab = 0.5, mgp = c(3, 1.3, 0), 
     labels = c(NA,2000,NA,NA,NA,NA,2005,NA,NA,NA,NA,2010,NA,NA,NA,NA,2015,NA))
axis(2, at = c(0,100,200,300), cex.axis = 1.5, mgp = c(3, 0.8, 0))
for (j in 1:30) {
  lines(c(1:17)*10, results90[j,], lwd = 4, col = rgb(0.75, 0.75, 0.75, 0.2), type = "l") }
lines(x <- c(1:17)*10, all.data[], cex = 1.2, type = "o", bg = "white", pch = 21)

# draw an empty plot
plot(x <- c(1:17)*10, all.data, xlim = c(-1, 183), ylim = c(0, 300), axes = FALSE, ann = FALSE, type = "n")
# add a border, axis titles and axes ticks to the plot
box(lwd = 1.5)
title(main = "50% Range Reduction", cex.lab = 1.5)
axis(1, at = seq(2, 180, by = 10), cex.axis = 1.5, cex.lab = 0.5, mgp = c(3, 1.3, 0), 
     labels = c(NA,2000,NA,NA,NA,NA,2005,NA,NA,NA,NA,2010,NA,NA,NA,NA,2015,NA))
axis(2, at = c(0,100,200,300), cex.axis = 1.5, mgp = c(3, 0.8, 0))
for (j in 1:30) {
  lines(c(1:17)*10, results50[j,], lwd = 4, col = rgb(0.75, 0.75, 0.75, 0.2), type = "l") }
lines(x <- c(1:17)*10, all.data[], cex = 1.2, type = "o", bg = "white", pch = 21)


######################################################################################
