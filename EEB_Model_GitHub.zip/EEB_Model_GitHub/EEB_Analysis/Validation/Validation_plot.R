######################################################################################
#                                                                                    #
#       POSTERIOR PLOTTING FOR VALIDATION OF EEB MODEL                               #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 8th May 2018                                                           #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

## plot.postCheck() takes the following arguments:
## abcEstObj = an object produced by create.abcEst() in ParameterEstimation.R;
## draws = the number of draws from the approximate
##      posterior parameter distribution to plot
## rerun = whether or not the underlying IBMs should actually be rerun

#-------------------------------------------------------------------------------------
# Plot function
#-------------------------------------------------------------------------------------

plot.postCheck <- function(abcEstObj, draws, rerun = FALSE) {	
  ## specify which columns of the data and simulation results relate to
  ## population size, adult mortality, births & calf mortality respectively
  col.e1 <- c(1:17)
  col.e2 <- c(18:34)
  col.e3 <- c(35:51)
  col.e4 <- c(52:68)
  
  ## find the empirical data to fit as stored in the abcEst object
  target <- unlist(all.data[1:68])
  all.data <- unlist(all.data)
  
  ## define plot attributes
  result.cols <- list(col.e1, col.e2, col.e3, col.e4)
  x.cors <- list(c(1:17)*10, c(1:17)*10, c(1:17)*10, c(1:17)*10)
  y.lims <- list(300, 40, 50, 40)
  y.labs <- list("Population Size","Adult and Juvenile Mortality", "Births", "Calf Mortality")
  x.ticks <- list(c(NA,2000,NA,NA,NA,NA,2005,NA,NA,NA,NA,2010,NA,NA,NA,NA,2015,NA))
  y.ticks <- list(c(0,100,200,300), c(0,10,20,30,40), c(0,10,20,30,40,50), c(0,10,20,30,40))
  leg <- list(270,25,41,17)
  
  ## setup for multiple plots
  par(mai = c(0.7,0.6,0.5,0.1), lwd = 2, mfrow = c(1,4))
  
  for (i in 1:4) {
    ## draw an empty plot
    plot(x <- x.cors[[i]], all.data[result.cols[[i]]], xlim = c(-1, 183),
         ylim = c(0, y.lims[[i]]), axes = FALSE, ann = FALSE, type = "n")
    
    ## add a border, axis titles and axes ticks to the plot
    box(lwd = 1.5)
    title(xlab = "", line = 3.85, cex.lab = 1.8)
    title(ylab = "", line = 2.75, cex.lab = 1.8)
    title(main = y.labs[[i]], line = 1, cex.main = 1.5)
    axis(1, at = seq(2, 180, by = 10), cex.axis = 1.8, cex.lab = 0.5, mgp = c(3, 1.3, 0), labels = x.ticks[[1]])
    axis(2, at = y.ticks[[i]], cex.axis = 1.8, mgp = c(3, 0.8, 0))
    
    ## plot data and 30 simulations
    for (j in 1:draws) {
      lines(x.cors[[i]], full.results[j, result.cols[[i]]],
            lwd = 4, col = rgb(0.75, 0.75, 0.75, 0.2), type = "l")
    }
    lines(x <- x.cors[[i]], mean_run[result.cols[[i]]], cex = 1.5, type = "l", col = "dimgrey", lwd = 4)
    
    lines(x <- x.cors[[i]], all.data[result.cols[[i]]], cex = 1.2,
          type = "o", bg = "white", pch = 21)
    legend("topleft", inset = c(-0.15, 0.1), #x = 1, y = leg[[i]],
           legend = substitute(expression(paste(R^2, " = ", RSQ, SIG)), list(RSQ = round(rsq[i], 2), SIG = sig[i]))[[2]],
           bty = "n", cex = 1.7,
           seg.len = 0.4, x.intersp = 0.6, y.intersp = 1.2)
  } }

