######################################################################################
#                                                                                    #
#       SCRIPT TO RUN NETLOGO MODEL VALIDATIION                                      #
#       Author: Vicky Boult                                                          #
#       Date: 11th April 2018                                                        #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

# load required packages
library(RNetLogo)        # hook up NL and R
library(parallel)        # run simulation sin parallel
library(plyr)            # for manipulating outputs

#-------------------------------------------------------------------------------------
# I. Initialise R for use with NetLogo
#-------------------------------------------------------------------------------------
# set working directory to location where NetLogo .jar file is located
setwd("C:/Program Files/NetLogo 6.0.2/app")
# the NetLogo installation path
nl.path <- getwd()
# the path to the NetLogo model file
model.path  <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Validation/EEB_240418_validation.nlogo"
# the simulation function (same simulation used in the ABC analysis)
simfun.path <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/ABC_simulation.R"
# load the code of the simulation function
source(file = simfun.path)

#-------------------------------------------------------------------------------------
# II. Prerequisites
#-------------------------------------------------------------------------------------
# define empirical data (population dynamics of resident elephant families)
target <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Validation/EEB_validation_data.txt", header = T)
# define number of parameter sets (number of parameter sets accepted in ABC)
sample.count <- 30
# how many repetitions for each parameter set should be run (to control stochasticity)?
no.repeated.sim <- 1
# read in accepted parameter sets 
param.val <- read.csv("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Validation/best30priors.csv", header = T)
# get names of parameters
param.names <- names(param.val)

#-------------------------------------------------------------------------------------
# III. Run the simulation for all parameter sets in PARALLEL
#-------------------------------------------------------------------------------------
# define functions required to run EEB in parallel
# the initialisation function - loads Netlogo model into each core
prepro <- function(dummy, gui, nl.path, model.path) {
  library(RNetLogo)
  NLStart(nl.path, gui = gui,  nl.jarname = "netlogo-6.0.2.jar")
  NLLoadModel(model.path)
}
# the simulation function
simfun <- simulate
# the quit function
postpro <- function(x) {
  NLQuit()
}
# create cluster (use all cores except 1 so you can still do other things whilst ABC runs!)
processors <- detectCores() - 1
cl <- makeCluster(processors)
# run NetLogo in headless mode - MUCH quicker!
gui = F
# load NetLogo in each core
invisible(parLapply(cl, 1:processors, prepro, gui = gui, nl.path = nl.path, model.path = model.path))
# run simulations (30 simulations across 7 cores ~no time at all!)
results.par <- parApply(cl, param.val, 1, simfun, 
                        no.repeated.sim = no.repeated.sim, 
                        nl.obj = NULL, trace.progress = F,
                        parameter.names = param.names, 
                        iter.length = sample.count,
                        function.name = "VAL")
# quit NetLogo in each core
invisible(parLapply(cl, 1:processors, postpro))
# close cluster
stopCluster(cl)
# reorganize the datasets 
sumstat <- ldply(results.par, data.frame)
# export results 
write.table(sumstat, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/validation_results1.txt", row.names = F, sep = " ")

#-------------------------------------------------------------------------------------
# IV. Assess validation fit
#-------------------------------------------------------------------------------------
# read in data again 
all.data <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Validation/EEB_validation_data.txt", header = T)
# read in all prior parameter set dataframes
full.priors <- param.val
# read in all results dataframes
full.results <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/validation_results.txt", header = T, stringsAsFactors = F)
# check dfs
head(full.priors)
head(full.results)

mean_run <- apply(full.results, 2, mean)
lm_table <- cbind.data.frame(mean_run,t(all.data))

pval <- c()
pval[1] <- summary(lm(lm_table[1:17,]))$coefficients[2,4]
pval[2] <- summary(lm(lm_table[18:34,]))$coefficients[2,4]
pval[3] <- summary(lm(lm_table[35:51,]))$coefficients[2,4]
pval[4] <- summary(lm(lm_table[52:68,]))$coefficients[2,4]

sig <- ifelse(pval < 0.05, z <- "*", z <- " ")

rsq <- c()
rsq[1] <- summary(lm(lm_table[1:17,]))$r.squared
rsq[2] <- summary(lm(lm_table[18:34,]))$r.squared
rsq[3] <- summary(lm(lm_table[35:51,]))$r.squared
rsq[4] <- summary(lm(lm_table[52:68,]))$r.squared

# load model fit plotting function
source("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Validation/Validation_plot.R")
# plot best fits
plot.postCheck(full.abcEst, draws = 30, rerun = FALSE)

######################################################################################
