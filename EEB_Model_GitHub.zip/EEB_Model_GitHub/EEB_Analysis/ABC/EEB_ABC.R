######################################################################################
#                                                                                    #
#       SCRIPT TO RUN APPROXIMATE BAYESIAN COMPUTATION ON EEB NETLOGO MODEL          #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 11th April 2018                                                        #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

# load required packages
library(RNetLogo)        # hook up NL and R
library(lhs)             # Latin Hypercube Sampling - to generate priors
library(parallel)        # run simulations in parallel
library(abc)             # Approximate Bayesian Computation
library(plyr)            # for manipulating outputs

#-------------------------------------------------------------------------------------
# I. Initialise R for use with NetLogo
#-------------------------------------------------------------------------------------
# set working directory to location where NetLogo .jar file is located
setwd("C:/Program Files/NetLogo 6.0.2/app")
# the NetLogo installation path
nl.path <- getwd()
# the path to the NetLogo model file
model.path  <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Model/EEB_240418.nlogo"
# the path to the simulation function
simfun.path <- "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/ABC_simulation.R"
# load the code of the simulation function
source(file = simfun.path)

#-------------------------------------------------------------------------------------
# II. Prerequisites
#-------------------------------------------------------------------------------------
# define empirical data (population dynamics of IB, LB, VA and WA families)
target <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/EEB_ILVW_data.txt", header = T)
# define number of parameter sets to generate
sample.count <- 100000
# how many repetitions for each parameter set should be run (to control stochasticity)?
no.repeated.sim <- 1
# set tolerance value for ABC (proportion of results accepted)
tol <- 0.0003 # accept 30 / 100000

#-------------------------------------------------------------------------------------
# III. Parameter generation (PRIORS)
#-------------------------------------------------------------------------------------
# define prior distributions of all uncertain parameters
# here, parameters chosen from uniform distribution ranging roughly half to double reference value
# (parameter names should be written exactly as in NetLogo model)
param.val <- list(
  "stor_scaling"  = list(min = 0.03, max = 0.12, random.function = "qunif"),
  "hsc"           = list(min = 0.115, max = 0.42, random.function = "qunif"),
  "maxIR_scaling" = list(min = 0.128, max = 0.51, random.function = "qunif"),
  "AE_veg"        = list(min = 0.13, max = 0.54, random.function = "qunif"),
  "con_eff"       = list(min = 0.42, max = 0.999, random.function = "qunif"),
  "B_0"           = list(min = 146, max = 586, random.function = "qunif"),
  "E0"            = list(min = 5900, max = 23000, random.function = "qunif"),
  "Epl"           = list(min = 56000, max = 225000, random.function = "qunif"),
  "back_mort"     = list(min = 0.0000135, max = 0.000054, random.function = "qunif"),
  "MR"            = list(min = 7500, max = 30000, random.function = "qunif"),
  "dd"            = list(min = 0, max = 1000000, random.function = "qunif")
)
# get names of parameters
param.names <- names(param.val)
# create standardised random values between 0 and 1 using Latin Hypercube Sampling
lhs.design <- randomLHS(sample.count, length(param.val))
# transform LHS values to real parameter values range and apply uniform distribution
lhs.design <- lapply(seq(1,length(param.val)), function(i) {
  match.fun(param.val[[i]]$random.function)(lhs.design[,i], param.val[[i]]$min, param.val[[i]]$max)
})
# column headings
names(lhs.design) <- param.names

#-------------------------------------------------------------------------------------
# IV. Run the simulation for all parameter sets in PARALLEL
#-------------------------------------------------------------------------------------
# define functions required to run EEB in parallel
# the initialisation function - loads NetLogo model into each core
prepro <- function(dummy, gui, nl.path, model.path) {
  library(RNetLogo)
  NLStart(nl.path, gui = gui,  nl.jarname = "netlogo-6.0.2.jar")
  NLLoadModel(model.path)
}
# the simulation function
simfun <- simulate
# the quit function - close NetLogo model in each core
postpro <- function(x) {
  NLQuit()
}
# create cluster (use all cores except 1 so you can still do other things whilst ABC runs!)
processors <- detectCores() - 1
cl <- makeCluster(processors)
# run NetLogo in headless mode - MUCH quicker!
gui = F
# load NetLogo in each core
invisible(parLapply(cl, 1:processors, prepro, gui = gui, nl.path = nl.path, model.path = model.path))

# 100,000 simulations of model across 7 cores takes 1-2 days
# so I suggest running following 7 procedures in one go 
# to ensure that computing power reduced and results saved as soon as simulations complete
# because by this point you should have gone home!

# run simulations across cluster
results.par <- parApply(cl, data.frame(lhs.design), 1, simfun, 
                        no.repeated.sim = no.repeated.sim, 
                        nl.obj = NULL, trace.progress = F,
                        parameter.names = param.names, 
                        iter.length = sample.count,
                        function.name = "ABC")
# quit NetLogo in each core and close cluster
invisible(parLapply(cl, 1:processors, postpro))
stopCluster(cl)
# reorganize the data (results and priors)
sumstat <- ldply(results.par, data.frame)
param <- as.data.frame(lhs.design)
# export ABC priors and results 
write.table(sumstat, file = "[INSERT FILE PATH]/ABC_results.txt", row.names = F, sep = " ")
write.table(param, file = "[INSERT FILE PATH]/ABC_priors.txt", row.names = F, sep = " ")

#-------------------------------------------------------------------------------------
# VI. Run the ABC
#-------------------------------------------------------------------------------------
# read in data again
all.data <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/EEB_ILVW_data.txt", header = T)
# read in priors dataframe
full.priors <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/ABC_priors.txt", header = T, stringsAsFactors = F)
# read in results dataframe
full.results <- read.table("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/ABC_results.txt", header = T, stringsAsFactors = F)

# check dfs
head(full.priors)
head(full.results)

# set up plot window for multiple plots (11 parameters)
par(mai = c(0.7,0.6,0.15,0.1), lwd = 2, mfrow = c(2,6))
# covariance calculation to get a feeling for a good tolerance value
cv.rej <- cv4abc(param = full.priors, sumstat = full.results, nval = 30, tols = c(.001,.005,.01,.1), method = "rejection")
summary(cv.rej)
plot(cv.rej)
# run the ABC with rejection sampling
method <- "rejection"
sim.results.abc.rej <- abc(target = all.data[1:68], param = full.priors, sumstat = full.results[1:68], tol = tol, method = method)
# plot the resulting posterior distribution for the parameters
hist(sim.results.abc.rej, breaks=10)
summary(sim.results.abc.rej,intvl=0.9)

#-------------------------------------------------------------------------------------
# VI. Posterior plotting
#-------------------------------------------------------------------------------------
# load parameter estimation function
source("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/ABC_parameter_estimation.R")
# estimate parameters
full.abcEst <- create.abcEst(target = all.data[1:68], priors = full.priors, results = full.results[1:68], rate = tol)
summary(full.abcEst)
# plot labels
labs <- c("stor_scaling","hsc","maxIR_scaling","AE_veg","AE_milk","B_0","E_0","E_PL","MR_back","MR_scaling","DD")
# plot prior and posterior parameter distributions
plot(full.abcEst)
# check information in abcEst object
print.abcEst(full.abcEst)
# parameter set producing best fitting model output
full.abcEst$best.values

# load model fit plotting function
source("[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/ABC/ABC_plotting.R")
# plot fits of accepted parameter sets
plot.postCheck(full.abcEst, draws = 30, rerun = FALSE)

# save 30 accepted results
best30 <- full.results[full.abcEst$accepted, ]
write.csv(best30, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/best30res.csv", row.names = F)
# save 1 best fitting result
best_1 <- full.results[99005, ]
write.csv(best_1, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/best1res.csv", row.names = F)
# save 30 accepted priors
best.priors <- full.priors[full.abcEst$accepted, ]
write.csv(best.priors, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/best30priors.csv", row.names = F)
# save 1 best fitting prior
best_1priors <- full.priors[99005,] 
write.csv(best_1priors, file = "[INSERT FILE PATH]/Elephant_Energy_Budget_IBM/EEB_Analysis/Results/best1priors.csv", row.names = F)

######################################################################################
