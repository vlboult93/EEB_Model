######################################################################################
#                                                                                    #
#       POSTERIOR PLOTTING FOR ABC OF EEB MODEL                                      #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 8th May 2018                                                           #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

## plot.postCheck() takes the following arguments:
## abcEstObj = an object produced by create.abcEst() in ABC_parameter_estimation.R;
## draws = the number of draws from the approximate posterior parameter distribution to plot
## rerun = whether or not the underlying IBMs should actually be rerun

#-------------------------------------------------------------------------------------
# Plot function
#-------------------------------------------------------------------------------------
plot.postCheck <- function(abcEstObj, draws, rerun = FALSE) {	
  ## specify which columns of the data and simulation results relate to
  ## population size, adult mortality, births & calf mortality respectively
  col.e1 <- c(1:17)
  col.e2 <- c(18:34)
  col.e3 <- c(35:51)
  col.e4 <- c(52:68)
  
  ## find the empirical data to fit as stored in the abcEst object
  target <- unlist(all.data[1:68])
  all.data <- unlist(all.data)
  ## randomly select 'draws' of the accepted runs to plot
  ran.draws <- sort(sample(1:nrow(as.data.frame(abcEstObj$priors[abcEstObj$accepted, ])),
                           draws, replace = TRUE))

  if (rerun) { 
    ## prepare some objects to store posterior checks in	
    results.best <- data.frame(matrix(nrow = draws, ncol = length(target)))
    accepted.runs <- data.frame(matrix(nrow = draws, ncol = length(target)))
    
    ## for as many times as specified by 'draws'...
    for (i in 1:draws) {
      ## run the model with the 'best' parameter values identified by ABC
      results.best[i, col.e1] <- do.runExp1(abcEstObj$best.values)
      results.best[i, col.e2] <- do.runExp2(abcEstObj$best.values)
      results.best[i, col.e3] <- do.runExp3(abcEstObj$best.values)
      results.best[i, col.e4] <- do.runExp4(abcEstObj$best.values)
      
      ## run the model with a random set of accepted parameter values
      accepted.runs[i, col.e1] <- do.runExp1(
        abcEstObj$priors[abcEstObj$accepted, ][ran.draws[i], ])
      accepted.runs[i, col.e2] <- do.runExp2(
        abcEstObj$priors[abcEstObj$accepted, ][ran.draws[i], ])
      accepted.runs[i, col.e3] <- do.runExp3(
        abcEstObj$priors[abcEstObj$accepted, ][ran.draws[i], ])
      accepted.runs[i, col.e4] <- do.runExp4(
        abcEstObj$priors[abcEstObj$accepted, ][ran.draws[i], ])
    }
    
    ## take the average of the runs using the 'best' parameter values
    results.best <- colMeans(results.best)
    
  } else {
    ## store the results of the best-fitting accepted run	
    results.best <- abcEstObj$results[abcEstObj$error == min(abcEstObj$error), ]
    best.row <- as.numeric(rownames(results.best))
    results.best <- full.results[best.row,]
    ## store the results of 'draws' of the accepted runs, selected randomly
    accepted.runs <- abcEstObj$results[abcEstObj$accepted, ]#[ran.draws, ]
    acc.rows <- as.numeric(rownames(accepted.runs))
    accepted.runs <- full.results[acc.rows,]
  }
  
  ## compute the fit of the best-fitting parameter set		
  rsqs.best <- c()
  rsqs.best[1] <- 1 - (sum((all.data[col.e1] - results.best[col.e1])^2) /
                         sum((all.data[col.e1] - mean(all.data[col.e1]))^2))
  rsqs.best[2] <- 1 - (sum((all.data[col.e2] - results.best[col.e2])^2) /
                         sum((all.data[col.e2] - mean(all.data[col.e1]))^2))
  rsqs.best[3] <- 1 - (sum((all.data[col.e3] - results.best[col.e3])^2) /
                         sum((all.data[col.e3] - mean(all.data[col.e3]))^2))
  rsqs.best[4] <- 1 - (sum((all.data[col.e4] - results.best[col.e4])^2) /
                         sum((all.data[col.e4] - mean(all.data[col.e4]))^2))
  
  ## specify the plot annotations which differ between Exp 1 & Exp 2 & Exp 3
  result.cols <- list(col.e1, col.e2, col.e3, col.e4)
  x.cors <- list(c(1:17)*10, c(1:17)*10, c(1:17)*10, c(1:17)*10)
  y.lims <- list(500, 30, 50, 20)
  y.labs <- list("Pop. size","Adult and Juvenile Mortality / year", "Births / year", "Calf Mortality / year")
  x.ticks <- list(c(NA,2000,NA,NA,NA,NA,2005,NA,NA,NA,NA,2010,NA,NA,NA,NA,2015,NA))
  y.ticks <- list(c(0,100,200,300,400,500), c(0,10,20,30), c(0,10,20,30,40,50), c(0,5,10,15,20))
  
  ## start the right kind of graphic device for the current operating system
  switch(Sys.info()[1], 
         Windows = { windows(width = 12, height = 3) },
         Linux = { x11(width = 12, height = 3) },
         Darwin = { quartz(width = 12, height = 3) },
         stop("Unknown OS! Can't plot.")
  )
  
  ## set the plot margins and default line width; divide the plot in 3/4 panels
  par(mai = c(0.7,0.6,0.15,0.1), lwd = 2, mfrow = c(1,5))
  
  ## create the legend in the first panel
  plot(x <- c(0, 1), y <- c(0, 1), type = "n", ann = FALSE, axes = FALSE, ylim = c(0,1), xlim = c(0,1))
  legend(0.06, 0.9,
         legend = c("empirical data", "best fitting run", "posterior check"),
         lwd = c(2, 4, 4, 4), pch = c(21, 20, 20), pt.cex = c(1.2, 0.001, 0.001),
         pt.bg = "white", col = c("black", "dimgrey", "grey"), cex = 1.6,
         bty = "n", seg.len = 1, title = expression(bold("legend")))
  
  ## automatically plot the posterior checks
  for (i in 1:4) {
    ## draw an empty plot
    plot(x <- x.cors[[i]], all.data[result.cols[[i]]], xlim = c(-1, 183),
         ylim = c(0, y.lims[[i]]), axes = FALSE, ann = FALSE, type = "n")
    
    ## add a border, axis titles and axes ticks to the plot
    box(lwd = 1.5)
    title(xlab = "", line = 3.85, cex.lab = 1.8)
    title(ylab = y.labs[[i]], line = 2.75, cex.lab = 1.8)
    axis(1, at = seq(2, 180, by = 10), cex.axis = 1.8, cex.lab = 0.5, mgp = c(3, 1.3, 0), labels = x.ticks[[1]])
    axis(2, at = y.ticks[[i]], cex.axis = 1.8, mgp = c(3, 0.8, 0))
    
    ## plot data, accepted runs and best fitting run
    for (j in 1:draws) {
      lines(x.cors[[i]], accepted.runs[j, result.cols[[i]]],
            lwd = 4, col = rgb(0.75, 0.75, 0.75, 0.2), type = "l")
    }
    lines(x <- x.cors[[i]], results.best[1,result.cols[[i]]],
          cex = 1.5, type = "l", col = "dimgrey", lwd = 4)
    lines(x <- x.cors[[i]], all.data[result.cols[[i]]], cex = 1.2,
          type = "o", bg = "white", pch = 21)
  }
}

