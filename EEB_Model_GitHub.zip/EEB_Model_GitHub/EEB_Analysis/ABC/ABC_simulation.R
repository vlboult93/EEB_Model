######################################################################################
#                                                                                    #
#       SIMULATION FUNCTION FOR ABC OF EEB MODEL                                     #
#       Author: Vicky Boult (adapted from Elske van der Vaart)                       #
#       Date: 8th May 2018                                                           #
#       For more info: victoria.boult@pgr.reading.ac.uk                              #
#                                                                                    #
######################################################################################

## simulate() takes the following arguments:
## param.set = priors for all parameters
## parameter.names = names of all parameters (as per NetLogo model)
## no.repeated.sims = number of repeated simulations to account for stochasticity
## nl.obj = netlogo instance (NULL in parallel)
## trace.progress = progress keeper (doesn't work in parallel)
## iter.length = number of parameter sets
## function.name = name of function

#-------------------------------------------------------------------------------------
# Simulation function
#-------------------------------------------------------------------------------------
simulate <- function(param.set, parameter.names, no.repeated.sim, nl.obj, trace.progress, iter.length, function.name) {
  # some security checks
  if (length(param.set) != length(parameter.names))
  { print(param.set)
    print(parameter.names)
    stop("Wrong length of param.set!") }
  if (no.repeated.sim <= 0)
  { stop("Number of repetitions must be > 0!") }
  if (length(parameter.names) <= 0)
  { stop("Length of parameter.names must be > 0!") }
  
  # an empty list to save the simulation results
  eval.vals <- NULL
  
  # repeated simulations (to control stochasticity)
  for (i in 1:no.repeated.sim)
  {
    # create a random-seed for NetLogo from R, based on min/max of NetLogo's random seed
    NLCommand("random-seed",56492, nl.obj = nl.obj)
    
    # For one simulation
    # run setup procedure
    NLCommand("setup", nl.obj = nl.obj)
    # set NetLogo parameters to current parameter values
    lapply(seq(1:length(parameter.names)), function(x) {NLCommand("set ", parameter.names[x], param.set[x], nl.obj = nl.obj)})
    # run simulation
    # advance model to 1st October 2000
    NLDoCommand(213,"go", nl.obj = nl.obj)
    # retrieve population data (population size, annual no. of adult deaths, births and calf deaths)
    counts2000 <- as.data.frame(NLReport(c("count turtles","a_death_count", "birth_count", "c_death_count"), nl.obj = nl.obj), col.names = c("E1_1", "E2_1", "E3_1", "E4_1"))
    # advance model by year and record population data annually
    countRest <- function(x) {
      f <- NLDoReport(1, "repeat 365 [go]", c("count turtles","a_death_count", "birth_count", "c_death_count"), as.data.frame = T, 
                      df.col.names = c(paste("E1_",x, sep = ""), paste("E2_",x, sep = ""), paste("E3_",x, sep = ""), paste("E4_",x, sep = "")), nl.obj = nl.obj)
      return(f)
    }
    countsAll <- lapply(2:17, countRest)
    # combine population data 2000-2016
    countsAll <- unlist(countsAll)
    countsAll <- t(as.data.frame(countsAll))
    counts.df <- merge.data.frame(counts2000, countsAll, all = T)
    counts.df <- counts.df[c(1,5,9,13,17,21,25,29,33,37,41,45,49,53,57,61,65,
                             2,6,10,14,18,22,26,30,34,38,42,46,50,54,58,62,66,
                             3,7,11,15,19,23,27,31,35,39,43,47,51,55,59,63,67,
                             4,8,12,16,20,24,28,32,36,40,44,48,52,56,60,64,68)]
    
    # append to former results
    eval.vals <- rbind(eval.vals, counts.df)
  }
  
  # print the progress if requested
  if (trace.progress == TRUE)
  {
    already.processed <- get("already.processed",env=globalenv()) + 1
    assign("already.processed", already.processed, env=globalenv())
    print(paste("processed (",function.name,"): ", already.processed / iter.length * 100, "%", sep = ""))
  }
  
  # return the mean of the repeated simulation results
  #if (no.repeated.sim > 1)
  #{
  #  return(eval.vals)
  #  #return(colMeans(eval.vals))
  #}
  #else {
  return(eval.vals)
  #}
}